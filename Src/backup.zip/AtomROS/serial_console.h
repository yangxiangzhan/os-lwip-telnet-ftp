#ifndef __SERIAL_SHELL_H__
#define __SERIAL_SHELL_H__



void vSerialConsole_Init(char * info);
void vShell_UpdateCmd(void * arg);

#endif


